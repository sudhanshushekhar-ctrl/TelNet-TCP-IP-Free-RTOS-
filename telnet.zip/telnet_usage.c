
#include <stdio.h>

#include "FreeRTOS_IP.h"
#include "FreeRTOS_Socket.h"
#include "telnet.h"

static Telnet_t myTelnet;

void setup_telnet()
{
	/*
	 * Make sure that the IP-stack is up and running before calling this function.
	 * Don't call more than once.
	 */
	xTelnetCreate( &myTelnet, TELNET_PORT_NUMBER );
}

void mainloop()
{
	struct freertos_sockaddr peer_address;
	char pcBuffer[ 129 ];

	for (;;)
	{
		BaseType_t xResult = xTelnetRecv( &( myTelnet ), &( peer_address ), pcBuffer, sizeof pcBuffer );
		if( xResult > 0 )
		{
			xResult = snprintf( pcBuffer, sizeof pcBuffer, "Thank you\n" );
			xTelnetSend( &( myTelnet ), &( peer_address ), pcBuffer, xResult );
		}
	}
}
